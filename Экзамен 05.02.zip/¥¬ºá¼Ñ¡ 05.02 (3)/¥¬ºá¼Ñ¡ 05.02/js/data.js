export const products = [{
        id: 1,
        title: "Блузка для девочек",
        price: 999,
        category: "Детская одежда",
        image: "./assets/img/image.png",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["белый", "розовый", "голубой"]
    },
    {
        id: 2,
        title: "Блузка для девочек",
        price: 1999,
        category: "Детская одежда",
        image: "./assets/img/image2.png",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["белый", "розовый", "голубой"]
    },
    {
        id: 3,
        title: "Блузка для женщин",
        price: 999,
        category: "Женская одежда",
        image: "./assets/img/image3.png",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["белый", "розовый", "голубой"]
    },
    {
        id: 4,
        title: "Блузка для женщин",
        price: 999,
        category: "Женская одежда",
        image: "./assets/img/image4.png",
        sizes: ["XS", "S", "M", "L", "XL"],
        colors: ["белый", "розовый", "голубой"]
    },
    // Мужская одежда
    {
        id: 5,
        title: "Мужская рубашка",
        price: 2499,
        category: "Мужская одежда",
        image: "./assets/img/men1.png",
        sizes: ["S", "M", "L", "XL"],
        colors: ["белый", "черный", "серый"]
    },
    {
        id: 6,
        title: "Мужские джинсы",
        price: 3999,
        category: "Мужская одежда",
        image: "./assets/img/men2.png",
        sizes: ["M", "L", "XL", "XXL"],
        colors: ["синий", "черный", "серый"]
    },
    // Женская одежда
    {
        id: 7,
        title: "Женское платье",
        price: 3599,
        category: "Женская одежда",
        image: "./assets/img/women1.png",
        sizes: ["XS", "S", "M"],
        colors: ["красный", "черный", "бежевый"]
    },
    {
        id: 8,
        title: "Женская блузка",
        price: 2199,
        category: "Женская одежда",
        image: "./assets/img/women2.png",
        sizes: ["XS", "S", "M", "L"],
        colors: ["белый", "розовый", "голубой"]
    }
];